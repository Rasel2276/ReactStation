// Demo 5 Js file
$(document).ready(function() {
    'use strict';
});