// Demo 9 Js file
$(document).ready(function () {
    'use strict';
});