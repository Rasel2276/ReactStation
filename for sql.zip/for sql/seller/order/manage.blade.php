@extends('seller.layouts.layout')
@section('seller_page_title')
     Manage store
@endsection
@section('seller_layout')
    Manage store
@endsection