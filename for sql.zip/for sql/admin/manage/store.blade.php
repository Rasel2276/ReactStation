@extends('admin.layouts.layout')
@section('admin_page_title')
Manage - Admin Panel
@endsection
@section('admin_layout')
    <h3>store  page</h3>
@endsection