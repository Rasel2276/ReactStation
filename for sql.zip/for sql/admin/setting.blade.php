@extends('admin.layouts.layout')
@section('admin_page_title')
Setting - Admin Panel
@endsection
@section('admin_layout')
    <h3>Setting page</h3>
@endsection